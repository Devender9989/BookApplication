package com.api.book.services;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.api.book.dao.BookRepository;
import com.api.book.entities.Book;

@Component
public class BookService
{	
	@Autowired
	private BookRepository bookRepository;
	
	public List<Book> getAllBooks()
	{
		List<Book> list =(List<Book>) bookRepository.findAll();
		return list;
	}
	
	
	//getBook by id
	public Book getBookById(int id) 
	{
		Book book = null;
		try
		{
			//given code is for database connectivity
			book = this.bookRepository.findById(id);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return book;
	}
	
	// adding a book 
	public Book addBook(Book b)
	{
		Book book = bookRepository.save(b);
		return book;
	}
	
	// delete a book
	public void deleteBook(int id)
	{
		bookRepository.deleteById(id);
	}
	
	//update book 
	public void updateBook(Book book, int bookid)
	{
		book.setBookid(bookid);
		bookRepository.save(book);
	}
	
}
