package com.api.book.entities;

import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.OneToOne;

@Entity
public class Book 
{
	@Id
	//@GeneratedValue(strategy = GenerationType.TABLE , generator = "custom-generator")
	private int bookid;
	private String title;
	private String publicationhouse;
	private int price;
	@OneToOne(cascade = CascadeType.ALL)
	@JsonManagedReference
	private Author author;
	
	public Book(int bookid, String title, Author author, String publicationhouse, int price) {
		super();
		this.bookid = bookid;
		this.title = title;
		this.author = author;
		this.publicationhouse = publicationhouse;
		this.price = price;
	}
	
	
	public int getBookid() {
		return bookid;
	}
	public void setBookid(int bookid) {
		this.bookid = bookid;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public Author getAuthor() {
		return author;
	}
	public void setAuthor(Author author) {
		this.author = author;
	}
	public String getPublicationhouse() {
		return publicationhouse;
	}
	public void setPublicationhouse(String publicationhouse) {
		this.publicationhouse = publicationhouse;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	
	
	public Book() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public String toString() {
		return "Book [bookid=" + bookid + ", title=" + title + ", author=" + author + ", publicationhouse="
				+ publicationhouse + ", price=" + price + "]";
	}
	

}
